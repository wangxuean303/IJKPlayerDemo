//
//  AppDelegate.h
//  MyPlayer
//
//  Created by Sorphiean on 17/6/20.
//  Copyright © 2017年 MC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

