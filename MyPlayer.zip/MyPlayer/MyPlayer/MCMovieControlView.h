//
//  MCMovieControlView.h
//  MyPlayer
//
//  Created by Sorphiean on 17/6/20.
//  Copyright © 2017年 MC. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol MCMovieControlDelegate <NSObject>
//点击暂停按钮
- (void)movieControlPauseOnClick;
//点击播放按钮
- (void)movieControlPlayOnClick;
//点击返回按钮
- (void)movieControlBackOnClick;
//点击快进按钮
- (void)movieControlSeekingForwardOnClick;
//点击快退按钮
- (void)movieControlSeekingBackwardOnClick;

@end

@protocol IJKMediaPlayback;

@interface MCMovieControlView : UIView

@property (nonatomic, weak) id<MCMovieControlDelegate>delegate;

@property(nonatomic,weak) id<IJKMediaPlayback> delegatePlayer;

- (void)refreshMediaControl;

@end
