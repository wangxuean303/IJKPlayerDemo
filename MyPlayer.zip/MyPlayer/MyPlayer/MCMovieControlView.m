//
//  MCMovieControlView.m
//  MyPlayer
//
//  Created by Sorphiean on 17/6/20.
//  Copyright © 2017年 MC. All rights reserved.
//

#import "MCMovieControlView.h"
#import <IJKMediaFramework/IJKMediaFramework.h>

@interface MCMovieControlView ()
@property (nonatomic, strong) UIButton *playButton;
@property (nonatomic, strong) UIButton *pauseButton;
@property (nonatomic, strong) UIButton *backButton;
@property (nonatomic, strong) UIButton *seekingForwardButton;
@property (nonatomic, strong) UIButton *seekingBackwardButton;

@property(nonatomic, strong) UILabel *currentTimeLabel;
@property(nonatomic, strong) UILabel *totalDurationLabel;
@property(nonatomic, strong) UISlider *mediaProgressSlider;

@property(nonatomic, assign) BOOL isMediaSliderBeingDragged;
@end

@implementation MCMovieControlView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self setupSubViews];
    }
    return self;
}

#pragma mark - action

- (void)actionBack:(UIButton *)button {
    if (self.delegate && [self.delegate respondsToSelector:@selector(movieControlBackOnClick)]) {
        [self.delegate movieControlBackOnClick];
    }
}

- (void)actionPlay:(UIButton *)button {
    if (self.delegate && [self.delegate respondsToSelector:@selector(movieControlPlayOnClick)]) {
        [self.delegate movieControlPlayOnClick];
    }
}

- (void)actionPause:(UIButton *)button {
    if (self.delegate && [self.delegate respondsToSelector:@selector(movieControlPauseOnClick)]) {
        [self.delegate movieControlPauseOnClick];
    }
}

- (void)actionSeekForward:(UIButton *)button {
    if (self.delegate && [self.delegate respondsToSelector:@selector(movieControlSeekingForwardOnClick)]) {
        [self.delegate movieControlSeekingForwardOnClick];
    }
}

- (void)actionSeekBackward:(UIButton *)button {
    if (self.delegate && [self.delegate respondsToSelector:@selector(movieControlSeekingBackwardOnClick)]) {
        [self.delegate movieControlSeekingBackwardOnClick];
    }
}

- (void)actionSliderTouchDown {
    _isMediaSliderBeingDragged = YES;
}

- (void)actionSliderTouchCancel {
    _isMediaSliderBeingDragged = NO;
}

- (void)actionSliderTouchUpOutside {
    _isMediaSliderBeingDragged = NO;
}

- (void)actionSliderTouchUpInside {
    self.delegatePlayer.currentPlaybackTime = self.mediaProgressSlider.value;
    _isMediaSliderBeingDragged = NO;
}

- (void)actionSliderValueChanged {
    [self refreshMediaControl];
}

#pragma mark - private

- (void)setupSubViews {
    self.backButton = [self buttonByTitle:@"返回" selector:@selector(actionBack:)];
    self.backButton.frame = CGRectMake(58, 270, 375 - 58 * 2, 50);
    [self addSubview:self.backButton];
    
    self.playButton = [self buttonByTitle:@"播放" selector:@selector(actionPlay:)];
    self.playButton.frame = CGRectMake(216, 130, 100, 50);
    [self addSubview:self.playButton];
    
    self.pauseButton = [self buttonByTitle:@"暂停" selector:@selector(actionPause:)];
    self.pauseButton.frame = CGRectMake(58, 130, 100, 50);
    [self addSubview:self.pauseButton];
    
    self.seekingForwardButton = [self buttonByTitle:@"快进" selector:@selector(actionSeekForward:)];
    self.seekingForwardButton.frame = CGRectMake(216, 200, 100, 50);
    [self addSubview:self.seekingForwardButton];
    
    self.seekingBackwardButton = [self buttonByTitle:@"快退" selector:@selector(actionSeekBackward:)];
    self.seekingBackwardButton.frame = CGRectMake(58, 200, 100, 50);
    [self addSubview:self.seekingBackwardButton];
    
    self.currentTimeLabel = [[UILabel alloc] initWithFrame:CGRectMake(45, 40, 50, 50)];
    self.currentTimeLabel.textAlignment = NSTextAlignmentRight;
    [self addSubview:self.currentTimeLabel];
    
    self.totalDurationLabel = [[UILabel alloc] initWithFrame:CGRectMake(375 - 95, 40, 50, 50)];
    self.totalDurationLabel.textAlignment = NSTextAlignmentLeft;
    [self addSubview:self.totalDurationLabel];
    
    self.mediaProgressSlider = [[UISlider alloc] initWithFrame:CGRectMake(100, 45, 175, 40)];
    self.mediaProgressSlider.value = 0;
    self.mediaProgressSlider.maximumValue = 1.0;
    [self.mediaProgressSlider addTarget:self action:@selector(actionSliderTouchDown) forControlEvents:UIControlEventTouchDown];
    [self.mediaProgressSlider addTarget:self action:@selector(actionSliderTouchCancel) forControlEvents:UIControlEventTouchCancel];
    [self.mediaProgressSlider addTarget:self action:@selector(actionSliderTouchUpOutside) forControlEvents:UIControlEventTouchUpOutside];
    [self.mediaProgressSlider addTarget:self action:@selector(actionSliderTouchUpInside) forControlEvents:UIControlEventTouchUpInside];
    [self.mediaProgressSlider addTarget:self action:@selector(actionSliderValueChanged) forControlEvents:UIControlEventValueChanged];
    [self addSubview:self.mediaProgressSlider];
}

- (UIButton *)buttonByTitle:(NSString *)title selector:(SEL)selecter {
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setTitle:title forState:UIControlStateNormal];
    [button setBackgroundColor:[UIColor whiteColor]];
    [button setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    button.layer.cornerRadius = 10;
    button.layer.masksToBounds = YES;
    [button addTarget:self action:selecter forControlEvents:UIControlEventTouchUpInside];
    return button;
}

- (void)refreshMediaControl
{
    // duration
    NSTimeInterval duration = self.delegatePlayer.duration;
    NSInteger intDuration = duration + 0.5;
    if (intDuration > 0) {
        self.mediaProgressSlider.maximumValue = duration;
        self.totalDurationLabel.text = [NSString stringWithFormat:@"%02d:%02d", (int)(intDuration / 60), (int)(intDuration % 60)];
    } else {
        self.totalDurationLabel.text = @"--:--";
        self.mediaProgressSlider.maximumValue = 1.0f;
    }
    
    
    // position
    NSTimeInterval position;
    if (_isMediaSliderBeingDragged) {
        position = self.mediaProgressSlider.value;
    } else {
        position = self.delegatePlayer.currentPlaybackTime;
    }
    NSInteger intPosition = position + 0.5;
    if (intDuration > 0) {
        self.mediaProgressSlider.value = position;
    } else {
        self.mediaProgressSlider.value = 0.0f;
    }
    self.currentTimeLabel.text = [NSString stringWithFormat:@"%02d:%02d", (int)(intPosition / 60), (int)(intPosition % 60)];
    
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(refreshMediaControl) object:nil];
    [self performSelector:@selector(refreshMediaControl) withObject:nil afterDelay:0.5];
}


@end
