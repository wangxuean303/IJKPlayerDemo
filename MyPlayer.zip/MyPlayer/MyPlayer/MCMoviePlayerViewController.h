//
//  MCMoviePlayerViewController.h
//  MyPlayer
//
//  Created by Sorphiean on 17/6/20.
//  Copyright © 2017年 MC. All rights reserved.
//

#import "ViewController.h"
#import <IJKMediaFramework/IJKMediaFramework.h>

@interface MCMoviePlayerViewController : ViewController 

@property (nonatomic, retain) id<IJKMediaPlayback> player;
+ (void)presentFromViewController:(UIViewController *)viewController withURLString:(NSString *)url completion:(void(^)())completion;
@end
