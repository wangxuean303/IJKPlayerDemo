//
//  MCMoviePlayerViewController.m
//  MyPlayer
//
//  Created by Sorphiean on 17/6/20.
//  Copyright © 2017年 MC. All rights reserved.
//

#import "MCMoviePlayerViewController.h"
#import "MCMovieControlView.h"

@interface MCMoviePlayerViewController () <MCMovieControlDelegate>
@property (nonatomic, strong) NSURL *url;
@property (nonatomic, strong) UIView *contentView;
@property (nonatomic, strong) UIView *headerView;
@property (nonatomic, strong) MCMovieControlView *controlView;
@end

@implementation MCMoviePlayerViewController

#pragma mark - init methods

+ (void)presentFromViewController:(UIViewController *)viewController withURLString:(NSString *)url completion:(void (^)())completion {
    [viewController presentViewController:[[MCMoviePlayerViewController alloc] initWithURLString:url] animated:YES completion:completion];
}

- (instancetype)initWithURLString:(NSString *)urlString {
    self = [super init];
    if (self) {
        self.url = [NSURL URLWithString:urlString];
    }
    return self;
}


#pragma mark - life cycle

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.contentView];
    [self.view bringSubviewToFront:self.contentView];
    
    self.controlView.delegate = self;
    [self.contentView addSubview:self.headerView];
    [self.contentView addSubview:self.controlView];
    
    //1.根据当前环境设置日志信息
#ifdef DEBUG
    //设置报告日志
    [IJKFFMoviePlayerController setLogReport:YES];
    //设置日志的级别为Debug
    [IJKFFMoviePlayerController setLogLevel:k_IJK_LOG_DEBUG];
#else
    //设置不报告日志
    [IJKFFMoviePlayerController setLogReport:NO];
    //设置日志级别为信息
    [IJKFFMoviePlayerController setLogLevel:k_IJK_LOG_INFO];
#endif
    
    //2.检查版本是否匹配
    [IJKFFMoviePlayerController checkIfFFmpegVersionMatch:YES];
    
    //3.创建IJKFFMoviePlayerController
    //注意：这里要先创建 IJKFFOptions 进行选项配置，然后再去创建播放器控制器    
    IJKFFOptions *options = [IJKFFOptions optionsByDefault];
    self.player = [[IJKFFMoviePlayerController alloc] initWithContentURL:self.url withOptions:options];
    
    //4.屏幕适配
    self.player.view.frame = CGRectMake(0, 0, 375, 285);
    self.player.scalingMode = IJKMPMovieScalingModeAspectFit;
    //加载完自动播放
    self.player.shouldAutoplay = YES;
    self.controlView.delegatePlayer = self.player;
    //添加player的view
    [self.headerView addSubview:self.player.view];

}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    //注册通知
    [self installMovieNotificationObservers];
    //当视图即将展示时准备播放
    [self.player prepareToPlay];
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    //关闭播放
    [self.player shutdown];
    //注销通知
    [self removeMovieNotificationObservers];
}

#pragma mark - private methods

- (void)loadStateDidChange:(NSNotification*)notification
{
    //    MPMovieLoadStateUnknown        = 0,               未知状态
    //    MPMovieLoadStatePlayable       = 1 << 0,          可播放状态
    //    MPMovieLoadStatePlaythroughOK  = 1 << 1,          当shouldAutoplay属性为YES时，这个状态下会自动播放
    //    MPMovieLoadStateStalled        = 1 << 2,          自动暂停
    
    IJKMPMovieLoadState loadState = _player.loadState;
    
    if ((loadState & IJKMPMovieLoadStatePlaythroughOK) != 0) {
        NSLog(@"加载状态：加载完自动播放");
    } else if ((loadState & IJKMPMovieLoadStateStalled) != 0) {
        NSLog(@"加载状态：加载完自动暂停");
    } else {
        NSLog(@"加载状态：其他状态");
    }
}

- (void)moviePlayBackDidFinish:(NSNotification*)notification
{
    //    MPMovieFinishReasonPlaybackEnded,         播放完毕导致的结束
    //    MPMovieFinishReasonPlaybackError,         播放出错导致的结束
    //    MPMovieFinishReasonUserExited             用户退出导致的结束
    int reason = [[[notification userInfo] valueForKey:IJKMPMoviePlayerPlaybackDidFinishReasonUserInfoKey] intValue];
    
    switch (reason)
    {
        case IJKMPMovieFinishReasonPlaybackEnded:
            NSLog(@"播放完毕导致的结束");
            break;
            
        case IJKMPMovieFinishReasonUserExited:
            NSLog(@"播放出错导致的结束");
            break;
            
        case IJKMPMovieFinishReasonPlaybackError:
            NSLog(@"用户退出导致的结束");
            break;
            
        default:
            NSLog(@"其他原因导致的结束");
            break;
    }
}



- (void)moviePlayBackStateDidChange:(NSNotification*)notification
{
    //    MPMoviePlaybackStateStopped,              停止
    //    MPMoviePlaybackStatePlaying,              正在播放
    //    MPMoviePlaybackStatePaused,               暂停
    //    MPMoviePlaybackStateInterrupted,          打断
    //    MPMoviePlaybackStateSeekingForward,       快进
    //    MPMoviePlaybackStateSeekingBackward       快退
    
    [self.controlView refreshMediaControl];
    switch (_player.playbackState)
    {
        case IJKMPMoviePlaybackStateStopped: {
            NSLog(@"播放状态改变 : 停止");
            break;
        }
        case IJKMPMoviePlaybackStatePlaying: {
            NSLog(@"播放状态改变 : 正在播放");
//            [self.controlView refreshMediaControl];
            break;
        }
        case IJKMPMoviePlaybackStatePaused: {
            NSLog(@"播放状态改变 : 暂停");
            break;
        }
        case IJKMPMoviePlaybackStateInterrupted: {
            NSLog(@"播放状态改变 : 打断");
            break;
        }
        case IJKMPMoviePlaybackStateSeekingForward: {
            NSLog(@"播放状态改变 : 快进");
            break;
        }
        case IJKMPMoviePlaybackStateSeekingBackward: {
            NSLog(@"播放状态改变 : 快退");
            break;
        }
        default: {
            NSLog(@"其他状态");
            break;
        }
    }
}

#pragma mark - MCMovieControlDelegate

//点击暂停按钮
- (void)movieControlPauseOnClick {
    [self.player pause];
}
//点击播放按钮
- (void)movieControlPlayOnClick {
    [self.player play];
}
//点击返回按钮
- (void)movieControlBackOnClick {
    [self.player pause];
    if (self.presentingViewController) {
        [self.presentingViewController dismissViewControllerAnimated:YES completion:nil];
    }
}
//点击快进按钮
- (void)movieControlSeekingForwardOnClick {
    self.player.currentPlaybackTime = (self.player.currentPlaybackTime + 5) >= self.player.duration ? self.player.duration : self.player.currentPlaybackTime + 5;
}
//点击快退按钮
- (void)movieControlSeekingBackwardOnClick {
    self.player.currentPlaybackTime = (self.player.currentPlaybackTime - 5) <= 0 ? 0 : self.player.currentPlaybackTime - 5;
}

#pragma mark - add & remove notification

-(void)installMovieNotificationObservers {
    //加载状态改变的通知
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(loadStateDidChange:)
                                                 name:IJKMPMoviePlayerLoadStateDidChangeNotification
                                               object:_player];
    
    //播放结束的通知
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(moviePlayBackDidFinish:)
                                                 name:IJKMPMoviePlayerPlaybackDidFinishNotification
                                               object:_player];
    
    //播放状态改变的通知
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(moviePlayBackStateDidChange:)
                                                 name:IJKMPMoviePlayerPlaybackStateDidChangeNotification
                                               object:_player];
}

-(void)removeMovieNotificationObservers {
    [[NSNotificationCenter defaultCenter]removeObserver:self name:IJKMPMoviePlayerLoadStateDidChangeNotification object:_player];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:IJKMPMoviePlayerPlaybackDidFinishNotification object:_player];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:IJKMPMediaPlaybackIsPreparedToPlayDidChangeNotification object:_player];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:IJKMPMoviePlayerPlaybackStateDidChangeNotification object:_player];
}

#pragma mark - getter

- (UIView *)contentView {
    if (!_contentView) {
        _contentView = [[UIView alloc] initWithFrame:self.view.bounds];
        _contentView.backgroundColor = [UIColor lightGrayColor];
    }
    return _contentView;
}

- (MCMovieControlView *)controlView {
    if (!_controlView) {
        _controlView = [[MCMovieControlView alloc] initWithFrame:CGRectMake(0, 285, 375, self.view.frame.size.height - 285)];
    }
    return _controlView;
}

- (UIView *)headerView {
    if (!_headerView) {
        _headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 375, 285)];
        _headerView.backgroundColor = [UIColor blackColor];
    }
    return _headerView;
}
@end
