//
//  ViewController.m
//  MyPlayer
//
//  Created by Sorphiean on 17/6/20.
//  Copyright © 2017年 MC. All rights reserved.
//

#import "ViewController.h"
#import "MCMoviePlayerViewController.h"
@interface ViewController ()
@property (nonatomic, strong) UIButton *startButton;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.startButton];
}


#pragma mark - actions

- (void)actionPlay:(UIButton *)button {
    //本地资源
    NSString *path = [[NSBundle mainBundle] pathForResource:@"my_video.mp4" ofType:nil];
    if ([[NSFileManager defaultManager] fileExistsAtPath:path]) {
        [MCMoviePlayerViewController presentFromViewController:self withURLString:path completion:^{
            NSLog(@"播放器初始化完成！");
        }];
    }    
}

#pragma mark - getter

- (UIButton *)startButton {
    if (!_startButton) {
        _startButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _startButton.frame = CGRectMake(0, 0, 150, 44);
        _startButton.center = self.view.center;
        _startButton.layer.cornerRadius = 5;
        _startButton.layer.masksToBounds = YES;
        [_startButton setBackgroundColor:[UIColor redColor]];
        [_startButton setTitle:@"点击开始播放" forState:UIControlStateNormal];
        [_startButton addTarget:self action:@selector(actionPlay:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _startButton;
}


@end
